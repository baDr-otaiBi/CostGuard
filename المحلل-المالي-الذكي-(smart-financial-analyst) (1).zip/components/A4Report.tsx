import React from 'react';
import { AIAnalysisResult, FinancialTheory } from '../types';
import { Printer, TrendingUp, AlertTriangle, Target, FileText, BookOpen, Lightbulb } from 'lucide-react';
import { FinancialBarChart, ExpensesPieChart, GenericBarChart, GenericPieChart } from './FinancialCharts';

interface A4ReportProps {
  data: AIAnalysisResult;
  onPrint: () => void;
  onBack: () => void;
}

const TheorySection: React.FC<{ theory: FinancialTheory; index: number }> = ({ theory, index }) => {
  return (
    <div className="mb-8 break-inside-avoid border border-slate-200 rounded-lg overflow-hidden">
      <div className="bg-slate-50 p-4 border-b border-slate-200 flex items-center justify-between">
         <h3 className="font-bold text-lg text-primary flex items-center gap-2">
            <span className="bg-primary text-white w-6 h-6 rounded-full flex items-center justify-center text-xs">{index + 1}</span>
            {theory.title}
         </h3>
      </div>
      <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
         <div className="md:col-span-2 space-y-4">
            <div className="text-sm text-slate-500 bg-blue-50 p-3 rounded border border-blue-100">
               <strong>المفهوم النظري:</strong> {theory.theoryDescription}
            </div>
            <div className="text-slate-800 leading-relaxed text-justify">
               <strong className="block mb-1 text-slate-900">تحليل بياناتك:</strong>
               {theory.applicationAnalysis}
            </div>
            <div className="flex items-start gap-2 text-green-700 bg-green-50 p-3 rounded border border-green-100">
               <Lightbulb size={20} className="shrink-0 mt-0.5" />
               <div>
                  <strong className="block text-sm">التوصية العملية:</strong>
                  {theory.actionableStep}
               </div>
            </div>
         </div>
         <div className="flex items-center justify-center bg-slate-50 rounded border border-slate-100 p-2">
            {theory.chartType === 'pie' ? (
                <GenericPieChart data={theory.chartData} height={200} />
            ) : (
                <GenericBarChart data={theory.chartData} height={200} />
            )}
         </div>
      </div>
    </div>
  );
};

export const A4Report: React.FC<A4ReportProps> = ({ data, onPrint, onBack }) => {
  return (
    <div className="flex flex-col items-center bg-gray-200 min-h-screen py-8 print:bg-white print:py-0">
      
      {/* Toolbar */}
      <div className="w-full max-w-[210mm] flex justify-between items-center mb-6 px-4 no-print">
        <button 
            onClick={onBack}
            className="flex items-center gap-2 text-slate-600 hover:text-slate-900 transition-colors bg-white px-4 py-2 rounded-lg shadow-sm"
        >
            ← عودة للوحة التحكم
        </button>
        <div className="flex gap-2">
            <button 
                onClick={onPrint}
                className="flex items-center gap-2 bg-primary text-white px-6 py-2 rounded-lg hover:bg-slate-800 shadow-lg transition-all"
            >
                <Printer size={20} />
                طباعة التقرير (PDF)
            </button>
        </div>
      </div>

      {/* A4 Paper Container */}
      <div className="a4-container">
        <div className="a4-paper text-slate-800">
            
            {/* Page 1: Executive Summary & KPIs */}
            <div className="h-full flex flex-col">
                <div className="border-b-4 border-slate-900 pb-6 mb-8 flex justify-between items-start">
                    <div>
                        <h1 className="text-5xl font-extrabold text-primary mb-2 tracking-tight">تقرير الأداء المالي</h1>
                        <h2 className="text-xl text-accent font-medium">تحليل معمق وتوصيات استراتيجية</h2>
                    </div>
                    <div className="text-left">
                        <img src="https://lucide.dev/favicon.ico" alt="Logo" className="w-12 h-12 mb-2 opacity-50 grayscale" />
                        <p className="text-slate-400 text-sm">التاريخ: {new Date().toLocaleDateString('ar-SA')}</p>
                    </div>
                </div>

                {/* Summary */}
                <section className="mb-10">
                    <h2 className="text-2xl font-bold text-slate-900 mb-4 flex items-center gap-2 border-b border-slate-100 pb-2">
                        <FileText className="text-accent" size={24} />
                        الملخص التنفيذي
                    </h2>
                    <div className="bg-slate-50 p-6 rounded-lg border-l-4 border-accent text-lg leading-relaxed text-justify shadow-sm">
                        {data.summary}
                    </div>
                </section>

                {/* KPIs */}
                <section className="mb-10">
                    <h2 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-2 border-b border-slate-100 pb-2">
                        <TrendingUp className="text-green-600" size={24} />
                        المؤشرات الرئيسية
                    </h2>
                    <div className="grid grid-cols-4 gap-4">
                        {data.kpis.map((kpi, idx) => (
                            <div key={idx} className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm text-center">
                                <p className="text-slate-500 text-xs mb-1 font-medium">{kpi.label}</p>
                                <p className="text-2xl font-bold text-slate-900 mb-2">{kpi.value}</p>
                                <span className={`text-xs px-2 py-0.5 rounded-full inline-flex items-center gap-1 ${
                                    kpi.trendDirection === 'up' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                                }`}>
                                    {kpi.trendDirection === 'up' ? '▲' : '▼'} {Math.abs(kpi.trend)}%
                                </span>
                            </div>
                        ))}
                    </div>
                </section>

                {/* Standard Charts */}
                <section className="flex-1">
                    <h2 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-2 border-b border-slate-100 pb-2">
                        <Target className="text-blue-600" size={24} />
                        التحليل البياني العام
                    </h2>
                    <div className="grid grid-cols-2 gap-8">
                        <div className="border border-slate-100 p-4 rounded-lg bg-white">
                             <h4 className="text-center mb-4 text-sm font-bold text-slate-600">التدفق المالي الشهري</h4>
                             <FinancialBarChart data={data.monthlyData} />
                        </div>
                        <div className="border border-slate-100 p-4 rounded-lg bg-white">
                            <h4 className="text-center mb-4 text-sm font-bold text-slate-600">هيكل المصروفات</h4>
                            <ExpensesPieChart data={data.expenseByCategory} />
                        </div>
                    </div>
                </section>
                
                <div className="text-center text-xs text-slate-300 mt-auto pt-4">صفحة 1 من 2</div>
            </div>
        </div>

        {/* Page 2: Advanced Theories & Strategy */}
        <div className="a4-paper text-slate-800 mt-8 print:mt-0 print:break-before-page">
            <div className="h-full flex flex-col">
                 <div className="border-b-2 border-slate-100 pb-4 mb-8">
                    <h2 className="text-xl font-bold text-slate-400">تابع: تقرير التحليل المالي</h2>
                </div>

                {/* Advanced Theories Section */}
                <section className="mb-10">
                    <h2 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-2 border-b border-slate-100 pb-2">
                        <BookOpen className="text-purple-600" size={24} />
                        تطبيق النظريات المالية (Advanced Analysis)
                    </h2>
                    
                    {data.advancedTheories?.map((theory, idx) => (
                        <TheorySection key={idx} theory={theory} index={idx} />
                    ))}
                </section>

                {/* Strategic Plan */}
                <section className="mb-8">
                    <h2 className="text-2xl font-bold text-slate-900 mb-4 flex items-center gap-2 border-b border-slate-100 pb-2">
                        <Target className="text-red-600" size={24} />
                        خارطة الطريق الاستراتيجية
                    </h2>
                    <div className="prose prose-slate prose-sm max-w-none text-justify whitespace-pre-line bg-white p-4">
                        {data.strategicPlan}
                    </div>
                </section>
                
                {/* Risks */}
                <section className="mt-auto mb-4 p-4 bg-orange-50 border-r-4 border-orange-400 rounded-r shadow-sm">
                    <h2 className="text-lg font-bold text-orange-800 mb-2 flex items-center gap-2">
                        <AlertTriangle size={18} />
                        تقييم المخاطر والمحاذير
                    </h2>
                    <p className="text-orange-900 text-sm leading-relaxed">{data.riskAssessment}</p>
                </section>

                <div className="text-center text-xs text-slate-300 pt-4 border-t border-slate-100">
                   تم إعداد هذا التقرير آلياً بواسطة نظام "المحلل المالي الذكي". صفحة 2 من 2
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};