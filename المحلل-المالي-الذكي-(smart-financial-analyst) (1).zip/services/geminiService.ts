import { GoogleGenAI, Type } from "@google/genai";
import { AIAnalysisResult } from "../types";

const processEnvApiKey = process.env.API_KEY;

// Fallback mock data updated with advanced structure
const MOCK_ANALYSIS: AIAnalysisResult = {
  summary: "يُظهر التحليل المالي وضعاً مستقراً مع نمو ملحوظ في الإيرادات، ولكن عند تطبيق مبدأ باريتو، وجدنا تركيزاً عالياً للمخاطر في مصادر دخل محدودة.",
  kpis: [
    { label: "إجمالي الإيرادات", value: "450,000 ر.س", trend: 15, trendDirection: "up" },
    { label: "صافي الربح", value: "120,000 ر.س", trend: 8, trendDirection: "up" },
    { label: "متوسط قيمة الطلب (AOV)", value: "350 ر.س", trend: 12, trendDirection: "up" },
    { label: "نقطة التعادل", value: "180,000 ر.س", trend: -2, trendDirection: "down" },
  ],
  monthlyData: [
    { name: "يناير", income: 300000, expense: 200000, profit: 100000 },
    { name: "فبراير", income: 350000, expense: 220000, profit: 130000 },
    { name: "مارس", income: 320000, expense: 250000, profit: 70000 },
    { name: "أبريل", income: 450000, expense: 330000, profit: 120000 },
  ],
  expenseByCategory: [
    { name: "رواتب", value: 150000 },
    { name: "تسويق", value: 80000 },
    { name: "تشغيل", value: 60000 },
    { name: "أخرى", value: 40000 },
  ],
  insights: [
    "تحليل الاتجاه يشير إلى نمو موسمي في الربع الأول.",
    "تكلفة الاستحواذ على العميل (CAC) ارتفعت بنسبة 10% رغم زيادة المبيعات."
  ],
  advancedTheories: [
    {
      title: "مبدأ باريتو (قاعدة 80/20)",
      theoryDescription: "ينص هذا المبدأ على أن 80% من النتائج تأتي من 20% من الأسباب. في سياق المبيعات، غالباً ما يأتي 80% من الدخل من 20% من المنتجات أو العملاء.",
      applicationAnalysis: "بتحليل بياناتك، وجدنا أن 3 منتجات فقط تساهم في 75% من إجمالي الأرباح. هذا يعني أن لديك اعتمادية عالية على عدد قليل من المنتجات.",
      actionableStep: "يجب التركيز على تسويق هذه المنتجات الثلاثة بشكل مكثف (Upselling)، مع محاولة تنويع سلة المنتجات لتقليل المخاطر.",
      chartType: "bar",
      chartData: [
        { name: "منتج أ (Top 20%)", value: 75 },
        { name: "باقي المنتجات (80%)", value: 25 }
      ]
    },
    {
      title: "تحليل هيكل التكاليف ونقطة التعادل",
      theoryDescription: "نقطة التعادل هي المرحلة التي تتساوى فيها التكاليف الكلية مع الإيرادات الكلية، مما يعني لا ربح ولا خسارة.",
      applicationAnalysis: "نقطة التعادل الحالية لديك هي عند مبيعات بقيمة 180,000 ريال شهرياً. أنت حالياً تتجاوز هذه النقطة بنسبة أمان 60%، وهو مؤشر ممتاز.",
      actionableStep: "حاول تقليل التكاليف الثابتة (مثل الإيجارات والرواتب الثابتة) لخفض نقطة التعادل وجعل العمل أكثر مرونة في الأشهر الضعيفة.",
      chartType: "pie",
      chartData: [
        { name: "هامش الأمان", value: 60 },
        { name: "نقطة التعادل", value: 40 }
      ]
    }
  ],
  strategicPlan: "...",
  riskAssessment: "...",
  recommendations: [
    { title: "تنويع مصادر الدخل", description: "الاعتماد الحالي على منتج واحد يشكل خطراً.", impact: "high" },
    { title: "تحسين دورة التحصيل", description: "متوسط فترة التحصيل مرتفع (45 يوماً).", impact: "medium" },
    { title: "أتمتة المخزون", description: "استخدام نظام باركود لتقليل الهدر.", impact: "low" }
  ]
};

export const analyzeFinancialData = async (rawData: string): Promise<AIAnalysisResult> => {
  if (!processEnvApiKey) {
    console.warn("API Key missing, using mock data.");
    return new Promise(resolve => setTimeout(() => resolve(MOCK_ANALYSIS), 3000));
  }

  const ai = new GoogleGenAI({ apiKey: processEnvApiKey });

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `
        أنت مدير مالي (CFO) مخضرم ومحلل بيانات استراتيجي. مهمتك ليست مجرد سرد الأرقام، بل تطبيق نظريات مالية واقتصادية لتقديم خارطة طريق لزيادة الربحية.
        
        البيانات الخام:
        ${rawData}

        المطلوب:
        قم بتحليل البيانات بعمق واستخرج تقريراً مهنياً بصيغة JSON يحتوي على التالي:

        1. **ملخص تنفيذي (summary)**: تقييم احترافي للوضع المالي.
        2. **مؤشرات الأداء (kpis)**: احسب بدقة (الإيرادات، صافي الربح، هامش الربح، متوسط قيمة الطلب AOV).
        3. **البيانات الشهرية (monthlyData)**.
        4. **توزيع المصروفات (expenseByCategory)**.
        
        5. **التحليل النظري المتقدم (advancedTheories)**: 
           قم باختيار وتطبيق نظريتين أو ثلاث نظريات مالية تناسب البيانات (مثل: مبدأ باريتو 80/20، تحليل نقطة التعادل Break-even، تحليل SWOT المالي، أو تحليل هوامش الربحية DuPont).
           لكل نظرية، يجب أن تقدم:
           - العنوان (title).
           - شرح النظرية (theoryDescription): شرح أكاديمي مبسط للقارئ.
           - التطبيق (applicationAnalysis): كيف تنطبق هذه النظرية بالضبط على أرقام هذا المستخدم؟ استشهد بالأرقام.
           - خطوة عملية (actionableStep): ماذا يجب أن يفعل المستخدم غداً بناءً على هذه النظرية؟
           - بيانات الرسم البياني (chartData): بيانات تمثل هذه النظرية (مثلاً لباريتو: قيمة أعلى 20% مقابل الباقي).

        6. **الخطة الاستراتيجية (strategicPlan)**: خطة عمل مكتوبة بتنسيق Markdown.
        7. **تقييم المخاطر (riskAssessment)**.
        8. **توصيات الذكاء الاصطناعي (recommendations)**: قائمة بتوصيات مباشرة (title, description, impact: high/medium/low).

        يجب أن تكون اللغة عربية فصحى، قوية، ومقنعة لرواد الأعمال.
      `,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            kpis: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  label: { type: Type.STRING },
                  value: { type: Type.STRING },
                  trend: { type: Type.NUMBER },
                  trendDirection: { type: Type.STRING, enum: ["up", "down", "neutral"] }
                }
              }
            },
            monthlyData: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  income: { type: Type.NUMBER },
                  expense: { type: Type.NUMBER },
                  profit: { type: Type.NUMBER }
                }
              }
            },
            expenseByCategory: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  value: { type: Type.NUMBER }
                }
              }
            },
            insights: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            advancedTheories: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  theoryDescription: { type: Type.STRING },
                  applicationAnalysis: { type: Type.STRING },
                  actionableStep: { type: Type.STRING },
                  chartType: { type: Type.STRING, enum: ["bar", "pie", "area"] },
                  chartData: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        name: { type: Type.STRING },
                        value: { type: Type.NUMBER }
                      }
                    }
                  }
                }
              }
            },
            strategicPlan: { type: Type.STRING },
            riskAssessment: { type: Type.STRING },
            recommendations: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  description: { type: Type.STRING },
                  impact: { type: Type.STRING, enum: ["high", "medium", "low"] }
                }
              }
            }
          }
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No data returned from AI");
    
    return JSON.parse(text) as AIAnalysisResult;

  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    return MOCK_ANALYSIS;
  }
};