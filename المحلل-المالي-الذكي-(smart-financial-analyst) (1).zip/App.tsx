import React, { useState, useEffect, useRef } from 'react';
import { 
  LayoutDashboard, 
  UploadCloud, 
  FileText, 
  ChevronRight, 
  BarChart3, 
  PieChart, 
  Zap,
  TrendingUp,
  ShieldAlert,
  ArrowRight,
  Loader2,
  ShoppingBag,
  CheckCircle2,
  Link as LinkIcon,
  Download,
  FileJson,
  FileSpreadsheet,
  Printer,
  Terminal
} from 'lucide-react';
import { analyzeFinancialData } from './services/geminiService';
import { AIAnalysisResult, AppView } from './types';
import { FinancialBarChart, ExpensesPieChart, ProfitAreaChart } from './components/FinancialCharts';
import { A4Report } from './components/A4Report';

const EXAMPLE_DATA = `
التاريخ,الوصف,المبلغ,النوع,الفئة
2023-01-05,دفعة عميل شركة الأفق,50000,income,مبيعات
2023-01-10,رواتب موظفين,25000,expense,رواتب
2023-01-15,إيجار المكتب,10000,expense,تشغيل
2023-01-20,مشروع تطوير برمجي,35000,income,مشاريع
2023-01-25,حملة إعلانية فيسبوك,5000,expense,تسويق
2023-02-02,دفعة عميل جديد,60000,income,مبيعات
2023-02-10,رواتب موظفين,25000,expense,رواتب
2023-02-12,شراء أجهزة لابتوب,8000,expense,أصول
2023-02-28,استشارة فنية,15000,income,خدمات
`;

// Simulated Salla Data Export
const SALLA_MOCK_DATA = `
رقم الطلب,تاريخ الطلب,العميل,حالة الطلب,إجمالي الطلب,طريقة الدفع,المدينة
102392,2023-11-01,عبدالله فهد,مكتمل,350,Apple Pay,الرياض
102393,2023-11-01,نورة سعيد,مكتمل,1250,Mada,جدة
102394,2023-11-02,محمد علي,جاري التوصيل,450,Visa,الدمام
102395,2023-11-02,مؤسسة التقنية,مكتمل,8900,تحويل بنكي,الرياض
102396,2023-11-03,خالد عمر,ملغي,0,Apple Pay,مكة
102397,2023-11-03,سارة احمد,مكتمل,220,Tamara,جدة
102398,2023-11-04,فهد ناصر,مسترجع,-350,Mada,الرياض
102399,2023-11-05,شركة الأفق,مكتمل,15000,تحويل بنكي,الدمام
102400,2023-11-05,علي حسن,مكتمل,99,Apple Pay,المدينة
102401,2023-11-06,منى خالد,مكتمل,4500,Visa,الرياض
102402,2023-11-08,متجر الهدايا,مكتمل,3200,Mada,ابها
--- مصروفات المتجر ---
تسويق,2023-11-01,إعلانات سناب شات,5000,expense,تسويق
اشتراكات,2023-11-01,باقة سلة برو,299,expense,تشغيل
لوجستيات,2023-11-10,شحن سمسا (دفعة),3000,expense,شحن
بضاعة,2023-11-15,شراء مخزون جديد,20000,expense,تكلفة بضاعة
رواتب,2023-11-25,رواتب فريق العمل,12000,expense,رواتب
`;

// Log messages to display during analysis
const ANALYSIS_LOGS = [
  "تهيئة الاتصال الآمن مع الخوادم...",
  "قراءة البيانات المدخلة والتحقق من التنسيق (CSV/JSON)...",
  "تحديد نوع البيانات (متجر إلكتروني / سجلات محاسبية)...",
  "إرسال البيانات إلى نموذج Gemini 3.0 Pro للمعالجة...",
  "جاري تصنيف المصروفات وتوحيد الفئات...",
  "حساب مؤشرات الأداء الرئيسية (KPIs)...",
  "تطبيق مبدأ باريتو (80/20) على مصادر الدخل...",
  "تحليل نقطة التعادل وهامش الأمان...",
  "كشف الأنماط الشاذة والمخاطر المحتملة...",
  "صياغة التوصيات الاستراتيجية باللغة العربية...",
  "توليد هيكل التقرير النهائي (JSON Schema)...",
  "جاري التحميل النهائي..."
];

function App() {
  const [view, setView] = useState<AppView>(AppView.LANDING);
  const [rawData, setRawData] = useState<string>('');
  
  // Analysis State
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [logs, setLogs] = useState<string[]>([]);
  const logsEndRef = useRef<HTMLDivElement>(null);
  
  // Salla State
  const [isConnectingSalla, setIsConnectingSalla] = useState(false);
  const [sallaConnected, setSallaConnected] = useState(false);
  
  const [analysisResult, setAnalysisResult] = useState<AIAnalysisResult | null>(null);

  // Scroll logs to bottom
  useEffect(() => {
    if (logsEndRef.current) {
      logsEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [logs]);

  const handleAnalysis = async () => {
    if (!rawData.trim()) return;
    
    setIsAnalyzing(true);
    setProgress(0);
    setLogs([]);
    
    // Start Progress Simulation
    let currentLogIndex = 0;
    const progressInterval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 90) return prev; // Hold at 90% until done
        return prev + Math.floor(Math.random() * 5) + 1;
      });

      // Add a log every few ticks
      if (Math.random() > 0.6 && currentLogIndex < ANALYSIS_LOGS.length) {
        setLogs(prev => [...prev, `> ${ANALYSIS_LOGS[currentLogIndex]}`]);
        currentLogIndex++;
      }
    }, 400);

    try {
      const result = await analyzeFinancialData(rawData);
      
      // Complete Progress
      clearInterval(progressInterval);
      setProgress(100);
      setLogs(prev => [...prev, "> تم اكتمال التحليل بنجاح!"]);
      
      // Short delay to show 100%
      setTimeout(() => {
        setAnalysisResult(result);
        setView(AppView.DASHBOARD);
        setIsAnalyzing(false);
      }, 800);

    } catch (error) {
      console.error("Analysis failed", error);
      clearInterval(progressInterval);
      setLogs(prev => [...prev, `> خطأ: ${error}`]);
      alert("حدث خطأ أثناء التحليل. يرجى المحاولة مرة أخرى.");
      setIsAnalyzing(false);
    }
  };

  const loadExampleData = () => {
    setRawData(EXAMPLE_DATA.trim());
    setSallaConnected(false);
  };

  const handleConnectSalla = () => {
    setIsConnectingSalla(true);
    // Simulate API delay
    setTimeout(() => {
      setRawData(SALLA_MOCK_DATA.trim());
      setSallaConnected(true);
      setIsConnectingSalla(false);
    }, 2000);
  };

  // -- Export Functions --
  const handlePrint = () => {
    window.print();
  };

  const downloadJSON = () => {
    if (!analysisResult) return;
    const jsonString = `data:text/json;chatset=utf-8,${encodeURIComponent(
      JSON.stringify(analysisResult, null, 2)
    )}`;
    const link = document.createElement("a");
    link.href = jsonString;
    link.download = "financial_analysis_report.json";
    link.click();
  };

  const downloadCSV = () => {
    if (!analysisResult) return;
    // Simple CSV conversion for monthly data
    const headers = ["الشهر", "الإيرادات", "المصروفات", "صافي الربح"];
    const rows = analysisResult.monthlyData.map(d => [d.name, d.income, d.expense, d.profit]);
    
    const csvContent = "data:text/csv;charset=utf-8,\uFEFF" 
        + headers.join(",") + "\n" 
        + rows.map(e => e.join(",")).join("\n");

    const link = document.createElement("a");
    link.href = encodeURI(csvContent);
    link.download = "financial_monthly_data.csv";
    link.click();
  };

  // -- Views --

  if (view === AppView.REPORT && analysisResult) {
    return (
      <A4Report 
        data={analysisResult} 
        onPrint={handlePrint} 
        onBack={() => setView(AppView.DASHBOARD)} 
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans">
      
      {/* Navigation */}
      <nav className="bg-primary text-white shadow-lg sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => setView(AppView.LANDING)}>
            <div className="bg-accent p-1.5 rounded-lg">
              <BarChart3 size={24} className="text-white" />
            </div>
            <span className="text-xl font-bold tracking-wide">المحلل المالي الذكي</span>
          </div>
          <div className="flex gap-6 text-sm font-medium text-slate-300">
            <button onClick={() => setView(AppView.LANDING)} className="hover:text-white transition-colors">الرئيسية</button>
            <button onClick={() => setView(AppView.INPUT)} className="hover:text-white transition-colors">تحليل جديد</button>
            {analysisResult && (
              <button onClick={() => setView(AppView.DASHBOARD)} className="hover:text-white transition-colors">اللوحة الحالية</button>
            )}
          </div>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="container mx-auto px-4 py-8 relative">
        
        {/* Progress Overlay (Same Page) */}
        {isAnalyzing && (
            <div className="fixed inset-0 bg-slate-900/90 z-[60] flex items-center justify-center p-4 backdrop-blur-sm animate-fade-in">
                <div className="bg-slate-800 border border-slate-700 w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden">
                    {/* Header */}
                    <div className="bg-slate-900 p-4 border-b border-slate-700 flex justify-between items-center">
                        <div className="flex items-center gap-2 text-white font-bold">
                            <Loader2 className="animate-spin text-accent" />
                            جاري تحليل البيانات المالية...
                        </div>
                        <span className="text-accent font-mono">{progress}%</span>
                    </div>

                    {/* Terminal Logs */}
                    <div className="p-6 bg-[#0c0c0c] font-mono text-sm h-64 overflow-y-auto custom-scrollbar relative">
                        {logs.map((log, i) => (
                            <div key={i} className="mb-2 text-green-500 animate-fade-in">
                                {log}
                            </div>
                        ))}
                        {progress < 100 && (
                             <div className="animate-pulse text-green-500/50">_</div>
                        )}
                        <div ref={logsEndRef} />
                    </div>

                    {/* Progress Bar */}
                    <div className="p-6 bg-slate-800">
                        <div className="w-full bg-slate-700 rounded-full h-4 overflow-hidden mb-2">
                            <div 
                                className="bg-accent h-4 rounded-full transition-all duration-300 ease-out flex items-center justify-center"
                                style={{ width: `${progress}%` }}
                            >
                                <div className="w-full h-full bg-white/20 animate-pulse"></div>
                            </div>
                        </div>
                        <p className="text-center text-slate-400 text-xs">
                            يرجى الانتظار، يتم الآن معالجة آلاف نقاط البيانات باستخدام Gemini 3.0 Pro
                        </p>
                    </div>
                </div>
            </div>
        )}

        {/* Landing View */}
        {view === AppView.LANDING && (
          <div className="flex flex-col items-center justify-center py-20 text-center animate-fade-in">
            <div className="bg-blue-50 text-accent px-4 py-1.5 rounded-full font-bold text-sm mb-6 border border-blue-100 inline-flex items-center gap-2">
              <Zap size={16} />
              مدعوم بنماذج Gemini 3.0 Pro
            </div>
            <h1 className="text-5xl md:text-7xl font-extrabold text-slate-900 mb-6 leading-tight">
              حول بياناتك المالية إلى <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-accent to-purple-600">قرارات ذكية</span>
            </h1>
            <p className="text-xl text-slate-600 max-w-2xl mb-10 leading-relaxed">
              ارفع ملفات المدفوعات والفواتير، أو اربط متجرك الإلكتروني (سلة) وسيقوم الذكاء الاصطناعي ببناء خطة استراتيجية دقيقة.
            </p>
            <div className="flex gap-4">
                <button 
                onClick={() => setView(AppView.INPUT)}
                className="group bg-slate-900 text-white text-lg px-8 py-4 rounded-xl font-bold shadow-xl hover:bg-slate-800 transition-all flex items-center gap-3"
                >
                ابدأ التحليل الآن
                <ArrowRight className="group-hover:translate-x-[-4px] transition-transform" />
                </button>
            </div>

            {/* Feature Grid */}
            <div className="grid md:grid-cols-3 gap-8 mt-24 text-right w-full max-w-5xl">
              {[
                { icon: <TrendingUp className="text-green-500" />, title: "تنبؤات دقيقة", desc: "استشراف المستقبل المالي بناءً على الأنماط التاريخية." },
                { icon: <ShoppingBag className="text-teal-500" />, title: "ربط مع سلة", desc: "تحليل مباشر لمبيعات المتجر، المخزون، وسلوك العملاء." },
                { icon: <ShieldAlert className="text-orange-500" />, title: "كشف المخاطر", desc: "تحديد فوري للعمليات غير المعتادة والهدر المالي." },
              ].map((feature, i) => (
                <div key={i} className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
                  <div className="mb-4 bg-slate-50 w-12 h-12 rounded-lg flex items-center justify-center">
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                  <p className="text-slate-500">{feature.desc}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Input View */}
        {view === AppView.INPUT && (
          <div className="max-w-3xl mx-auto animate-fade-in">
             <div className="flex items-center gap-4 mb-8">
               <button onClick={() => setView(AppView.LANDING)} className="text-slate-400 hover:text-slate-900">
                 <ArrowRight />
               </button>
               <h2 className="text-3xl font-bold text-slate-800">إدخال البيانات المالية</h2>
             </div>

             <div className="grid md:grid-cols-2 gap-4 mb-6">
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex flex-col justify-between">
                    <div>
                        <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center text-blue-600 mb-4">
                            <FileText size={24} />
                        </div>
                        <h3 className="font-bold text-lg mb-2">إدخال يدوي / ملفات</h3>
                        <p className="text-sm text-slate-500">نسخ ولصق بيانات CSV أو JSON من نظامك المحاسبي.</p>
                    </div>
                </div>

                <div className="bg-gradient-to-br from-[#004D5A] to-[#003840] p-6 rounded-2xl shadow-lg border border-teal-800 flex flex-col justify-between relative overflow-hidden group">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-teal-500 blur-[50px] opacity-20 rounded-full pointer-events-none"></div>
                    <div>
                        <div className="w-12 h-12 bg-white/10 rounded-lg flex items-center justify-center text-[#B6F396] mb-4 backdrop-blur-sm">
                            <ShoppingBag size={24} />
                        </div>
                        <h3 className="font-bold text-lg mb-2 text-white">ربط مع متجر سلة</h3>
                        <p className="text-sm text-slate-300">سحب الطلبات والمبيعات تلقائياً للتحليل المباشر.</p>
                    </div>
                    <button 
                        onClick={handleConnectSalla}
                        disabled={isConnectingSalla || sallaConnected}
                        className={`mt-4 w-full py-2.5 rounded-lg font-bold text-sm transition-all flex items-center justify-center gap-2 ${
                            sallaConnected 
                            ? 'bg-[#B6F396] text-[#004D5A] cursor-default' 
                            : 'bg-white text-[#004D5A] hover:bg-slate-100'
                        }`}
                    >
                        {isConnectingSalla ? (
                            <Loader2 size={16} className="animate-spin" />
                        ) : sallaConnected ? (
                            <>
                                <CheckCircle2 size={16} />
                                تم الربط بنجاح
                            </>
                        ) : (
                            <>
                                <LinkIcon size={16} />
                                اربط الآن
                            </>
                        )}
                    </button>
                </div>
             </div>

             <div className="bg-white p-8 rounded-2xl shadow-lg border border-slate-200 relative">
               {sallaConnected && (
                   <div className="absolute top-4 left-4 bg-[#B6F396]/20 text-[#004D5A] px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1 border border-[#B6F396]">
                       <ShoppingBag size={12} />
                       بيانات سلة مستوردة
                   </div>
               )}
               <label className="block text-slate-700 font-medium mb-4">
                 البيانات المالية للتحليل:
               </label>
               <textarea
                 value={rawData}
                 onChange={(e) => {
                     setRawData(e.target.value);
                     if(sallaConnected) setSallaConnected(false); // Reset salla flag if user edits manually
                 }}
                 className="w-full h-64 p-4 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-accent focus:border-transparent outline-none font-mono text-sm text-slate-700 mb-4"
                 placeholder='مثال: {"date": "2024-01-01", "amount": 5000, "type": "income"}...'
               />
               
               <div className="flex justify-between items-center">
                 <button 
                   onClick={loadExampleData}
                   className="text-sm text-slate-500 hover:text-accent underline"
                 >
                   استخدم بيانات تجريبية (عامة)
                 </button>
                 
                 <button 
                    onClick={handleAnalysis}
                    disabled={isAnalyzing || !rawData.trim()}
                    className={`flex items-center gap-2 bg-accent text-white px-8 py-3 rounded-xl font-bold shadow-lg transition-all hover:bg-blue-600 hover:shadow-blue-500/30`}
                 >
                    <Zap size={20} />
                    تحليل البيانات
                 </button>
               </div>
             </div>
          </div>
        )}

        {/* Dashboard View */}
        {view === AppView.DASHBOARD && analysisResult && (
          <div className="animate-fade-in pb-20">
            {/* Header Section */}
            <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center mb-10 gap-4">
              <div>
                <h2 className="text-3xl font-bold text-slate-900">لوحة القيادة المالية</h2>
                <p className="text-slate-500 mt-1">نظرة عامة شاملة محدثة لحظياً</p>
              </div>
              
              {/* Alternative Download Options */}
              <div className="flex flex-wrap gap-2">
                 <button 
                    onClick={downloadCSV}
                    className="bg-white border border-slate-300 text-slate-700 px-4 py-2.5 rounded-lg flex items-center gap-2 hover:bg-slate-50 transition-colors shadow-sm text-sm font-bold"
                  >
                    <FileSpreadsheet size={16} className="text-green-600" />
                    تصدير CSV
                  </button>
                  <button 
                    onClick={downloadJSON}
                    className="bg-white border border-slate-300 text-slate-700 px-4 py-2.5 rounded-lg flex items-center gap-2 hover:bg-slate-50 transition-colors shadow-sm text-sm font-bold"
                  >
                    <FileJson size={16} className="text-orange-600" />
                    تحميل JSON
                  </button>
                  <div className="w-px h-10 bg-slate-300 mx-1 hidden md:block"></div>
                  <button 
                    onClick={() => setView(AppView.REPORT)}
                    className="bg-slate-900 text-white px-6 py-2.5 rounded-lg flex items-center gap-2 hover:bg-slate-800 transition-colors shadow-lg"
                  >
                    <Printer size={18} />
                    عرض التقرير / طباعة PDF
                  </button>
              </div>
            </div>

            {/* KPI Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
              {analysisResult.kpis.map((kpi, index) => (
                <div key={index} className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm relative overflow-hidden group hover:shadow-md transition-all">
                  <div className="absolute top-0 right-0 w-2 h-full bg-gradient-to-b from-transparent via-accent/20 to-transparent group-hover:via-accent/40 transition-all"></div>
                  <h3 className="text-slate-500 text-sm font-medium mb-2">{kpi.label}</h3>
                  <div className="flex items-end justify-between">
                    <span className="text-2xl font-bold text-slate-900">{kpi.value}</span>
                    <span className={`text-sm font-bold px-2 py-1 rounded flex items-center gap-1 ${
                      (kpi.trendDirection === 'up' && !kpi.label.includes('مصروفات')) || (kpi.trendDirection === 'down' && kpi.label.includes('مصروفات'))
                      ? 'bg-green-100 text-green-700' 
                      : 'bg-red-100 text-red-700'
                    }`}>
                      {kpi.trend}%
                      {kpi.trendDirection === 'up' ? '↑' : '↓'}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Main Charts Row */}
            <div className="grid lg:grid-cols-3 gap-8 mb-10">
              <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="font-bold text-lg text-slate-800">تحليل الإيرادات والمصروفات</h3>
                  <select className="bg-slate-50 border border-slate-200 text-sm rounded-lg px-3 py-1 outline-none">
                    <option>آخر 6 أشهر</option>
                    <option>هذا العام</option>
                  </select>
                </div>
                <FinancialBarChart data={analysisResult.monthlyData} />
              </div>
              
              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                <h3 className="font-bold text-lg text-slate-800 mb-6">توزيع المصروفات</h3>
                <ExpensesPieChart data={analysisResult.expenseByCategory} />
              </div>
            </div>

            {/* AI Insights & Recommendations */}
            <div className="grid lg:grid-cols-2 gap-8">
              
              {/* Recommendations */}
              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                 <div className="flex items-center gap-2 mb-6">
                    <div className="p-2 bg-purple-100 rounded-lg text-purple-600">
                        <Zap size={20} />
                    </div>
                    <h3 className="font-bold text-lg text-slate-800">توصيات الذكاء الاصطناعي</h3>
                 </div>
                 <div className="space-y-4">
                    {analysisResult.recommendations.map((rec, i) => (
                        <div key={i} className="flex gap-4 p-4 rounded-xl bg-slate-50 border border-slate-100 hover:border-purple-200 transition-colors">
                            <div className={`w-1 shrink-0 rounded-full ${
                                rec.impact === 'high' ? 'bg-red-500' : rec.impact === 'medium' ? 'bg-orange-400' : 'bg-green-400'
                            }`}></div>
                            <div>
                                <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                                    {rec.title}
                                    <span className={`text-[10px] px-2 py-0.5 rounded-full border ${
                                        rec.impact === 'high' ? 'border-red-200 text-red-600 bg-red-50' : 'border-orange-200 text-orange-600 bg-orange-50'
                                    }`}>
                                        أثر {rec.impact === 'high' ? 'عالٍ' : 'متوسط'}
                                    </span>
                                </h4>
                                <p className="text-sm text-slate-500 mt-1 leading-relaxed">{rec.description}</p>
                            </div>
                        </div>
                    ))}
                 </div>
              </div>

              {/* Profit Trend & Insights */}
              <div className="flex flex-col gap-8">
                 <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex-1">
                    <h3 className="font-bold text-lg text-slate-800 mb-4">اتجاه صافي الربح</h3>
                    <ProfitAreaChart data={analysisResult.monthlyData} />
                 </div>

                 <div className="bg-slate-900 text-white p-6 rounded-2xl shadow-lg relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-32 h-32 bg-accent blur-[60px] opacity-20 rounded-full pointer-events-none"></div>
                    <h3 className="font-bold text-lg mb-4 relative z-10 flex items-center gap-2">
                        <ShieldAlert size={18} className="text-accent" />
                        رؤى تحليلية عميقة
                    </h3>
                    <ul className="space-y-3 relative z-10">
                        {analysisResult.insights.map((insight, i) => (
                            <li key={i} className="flex gap-3 text-sm text-slate-300">
                                <span className="text-accent mt-1">•</span>
                                {insight}
                            </li>
                        ))}
                    </ul>
                 </div>
              </div>
            </div>

          </div>
        )}
      </main>
    </div>
  );
}

export default App;